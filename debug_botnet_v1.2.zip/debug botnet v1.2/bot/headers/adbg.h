#pragma once

#ifndef ADBG_H
#define ADBG_H

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

void adbg();

#endif // ADBG_H
