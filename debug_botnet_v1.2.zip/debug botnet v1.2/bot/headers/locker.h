#pragma once

#ifndef LOCKER_H
#define LOCKER_H

#include <limits.h>

void start_locker(void);

#endif // LOCKER_H
