#pragma once

#ifndef SYN_ATTACK_H
#define SYN_ATTACK_H

#include "../headers/attack_params.h"

void* syn_attack(void* arg);

#endif // SYN_ATTACK_H
