#pragma once

#ifndef KILLER_H
#define KILLER_H

#include <limits.h>

void start_killer(void);
void stop_killer(void);

#endif // KILLER_H
